# Acorn

A tiny, fast JavaScript parser in JavaScript.

See http://marijnhaverbeke.nl/acorn/
