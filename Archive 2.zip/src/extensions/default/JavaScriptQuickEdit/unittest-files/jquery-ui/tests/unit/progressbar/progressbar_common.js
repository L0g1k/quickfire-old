TestHelpers.commonWidgetTests( "progressbar", {
	defaults: {
		disabled: false,
		value: 0,
		max: 100,

		//callbacks
		create: null
	}
});
