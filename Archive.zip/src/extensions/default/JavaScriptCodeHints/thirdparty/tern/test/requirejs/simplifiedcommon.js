define(function(require, exports) {
  exports.hello = require("foo").aString;
});
