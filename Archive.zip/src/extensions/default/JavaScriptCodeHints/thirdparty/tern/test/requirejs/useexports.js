define(["exports"], function(exports) {
  exports.hello = true;
});
