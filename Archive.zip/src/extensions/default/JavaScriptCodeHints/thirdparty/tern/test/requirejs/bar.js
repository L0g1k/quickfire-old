define(["baz"], function(baz) {
  return {aNumber: 10, baz: baz};
});
