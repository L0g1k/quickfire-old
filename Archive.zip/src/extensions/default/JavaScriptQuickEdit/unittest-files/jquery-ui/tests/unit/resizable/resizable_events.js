/*
 * resizable_events.js
 */
(function($) {

module("resizable: events");

})(jQuery);
